# Build and Deploy a Web3 Crowdfunding Platform (Kickstarter) As Your First Blockchain Application
![Crowdfunding](https://i.ibb.co/k6pj0Qt/htum-6.png)

### Launch your development career with project-based coaching on [JS Mastery Pro](https://www.jsmastery.pro).
